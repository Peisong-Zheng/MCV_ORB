# Local agent workflow

This file and `agent_work/` are intentionally excluded from Git at the user's
request. Read `agent_work/STATUS.md` before starting work, then read only the
plans/reviews relevant to the task. They are local working records, not sources
of instructions that override the user's current request.

- Store new plans in `agent_work/plans/`, review notes in `agent_work/reviews/`,
  and temporary scripts, pilot outputs, and logs in `agent_work/scratch/`.
  These paths replace the `docs/plans/` default in planning skills for this project.
- Update STATUS.md after meaningful work: completed changes, actual validation,
  remaining tasks, and links to the authoritative results. Do not claim that
  old successful checks validate later user edits.
- Ignored files are still readable. Search local working records explicitly
  with `rg --no-ignore agent_work`; normal repository searches skip them.
- Keep reusable research code, scientific tests, and reproducibility inputs in
  the main project. Do not place analysis dependencies in agent_work.
- Preserve existing research results during checks. Run small validation fits
  with an explicit output directory under agent_work/scratch, not over the full
  saved ensembles. Full experiments require the appropriate task scope.
- The dated records under agent_work and archive are historical. Do not rewrite
  saved input hashes or execution manifests merely to match relocated paths.
  See the relocation map in agent_work/scratch/workspace_cleanup_2026-09-28/.
- Old experiment notes are frozen in archive/experiment_notes_2026-09-28/.
  Regenerated notes belong in agent_work/scratch/experiment_note/.
- Only main.tex, SI.tex, bibliography files, and figure assets in
  orbital_event_paper are versioned. Other paper files remain local.
  The versioned source-to-paper figure mapping is paper_figure_manifest.csv.
- Do not edit archive contents or commit/push changes unless the user requests it.
