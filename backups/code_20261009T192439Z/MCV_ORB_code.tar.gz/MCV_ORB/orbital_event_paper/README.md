# Manuscript and Supporting Information

[main.tex](main.tex) describes the event catalogues and continuous-time analysis
of warming occurrence. [SI.tex](SI.tex) gives the event-timing and chronology
methods, bootstrap tests, uncertainty calculations and sensitivity analyses.
Both use [reference.bib](reference.bib).

The [figures](figures/) directory contains the manuscript figure assets.
[paper_figure_manifest.csv](../paper_figure_manifest.csv) maps them to their
source analysis figures.

## Compile

With LaTeX, `latexmk`, and the AGU bibliography style (`agu.bst`) installed,
run from this directory:

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error SI.tex
```

Compilation uses the saved figures. See the [project README](../README.md) for
the analysis code and data preparation.
