"""Barker reuses the continuous null driver with its own source and seed."""
import numpy as np
import pandas as pd
import pytest
from Barker2011 import Barker2011_likelihood_bootstrap as bootstrap


@pytest.fixture(scope="module")
def result():
    return bootstrap.run_analysis(n_bootstrap=4, seed=191)


@pytest.fixture(scope="module")
def fixed_result():
    return bootstrap.run_analysis(n_bootstrap=2, seed=193, event_definition="fixed_threshold")


def test_primary_catalogue_support_and_observed_statistic(result):
    assert len(result["events"]) == 70
    assert result["events"].event_id.str.startswith("Barker_S3_").all()
    assert result["summary"].event_definition.item() == "variable_threshold"
    assert result["summary"].n_response_events.item() == 69
    assert result["summary"].LR_statistic.item() == pytest.approx(10.582480594, abs=1e-6)
    assert result["summary"].response_exposure_kyr.item() == pytest.approx(396.4642638777)
    assert result["replicates"].fit_valid.all()
    assert bootstrap.RANDOM_SEED == 20260909 and bootstrap.N_BOOTSTRAP == 9999


def test_shared_driver_parallel_and_serial_agree(result):
    parallel = bootstrap.run_analysis(n_bootstrap=4, seed=191, n_workers=2)
    pd.testing.assert_frame_equal(result["replicates"], parallel["replicates"])
    np.testing.assert_allclose(result["summary"].empirical_p_plus_one,
                               parallel["summary"].empirical_p_plus_one)


def test_fixed_threshold_uses_own_anchor_background_and_null(fixed_result, result):
    fixed = fixed_result
    assert len(fixed["events"]) == 59
    assert fixed["summary"].event_definition.item() == "fixed_threshold"
    assert fixed["summary"].n_response_events.item() == 58
    assert fixed["summary"].LR_statistic.item() == pytest.approx(8.57672375244, abs=1e-6)
    assert fixed["summary"].response_exposure_kyr.item() == pytest.approx(392.245695897)
    assert fixed["summary"].response_exposure_kyr.item() != result["summary"].response_exposure_kyr.item()
    assert not fixed["scaling"].equals(result["scaling"])
    # The two definitions must not share the fitted BG model or reference LR.
    assert fixed["reduced"].log_likelihood != result["reduced"].log_likelihood
    assert fixed["replicates"].fit_valid.all()
    assert fixed["summary"].event_definition.item() == "fixed_threshold"
    row = fixed["summary"].iloc[0]
    exceedances = (fixed["replicates"].LR_statistic >= row.LR_statistic).sum()
    assert row.empirical_p_plus_one == (exceedances + 1) / (len(fixed["replicates"]) + 1)


def test_fixed_outputs_do_not_replace_variable_outputs(fixed_result, result, tmp_path):
    data_dir, figure_dir = bootstrap.output_directories(tmp_path, "variable_threshold")
    fixed_data, fixed_figure = bootstrap.output_directories(tmp_path, "fixed_threshold")
    bootstrap.save_tables(result, data_dir)
    original_summary = (data_dir / "summary.csv").read_bytes()
    bootstrap.save_tables(fixed_result, fixed_data)
    assert (data_dir / "summary.csv").read_bytes() == original_summary
    assert fixed_figure == figure_dir / "fixed_threshold"
    assert pd.read_csv(fixed_data / "summary.csv").event_definition.item() == "fixed_threshold"


def test_barker_staged_outputs_and_figure(result, tmp_path):
    import matplotlib.pyplot as plt
    bootstrap.save_tables(result, tmp_path / "data")
    assert {path.name for path in (tmp_path / "data").iterdir()} == {
        "summary.csv", "bootstrap_replicates.csv"}
    replicates = pd.read_csv(tmp_path / "data/bootstrap_replicates.csv")
    summary = pd.read_csv(tmp_path / "data/summary.csv")
    np.testing.assert_allclose(replicates.LR_statistic, result["replicates"].LR_statistic, rtol=1e-11)
    n_exceed = (replicates.LR_statistic >= summary.LR_statistic.item()).sum()
    assert summary.empirical_p_plus_one.item() == pytest.approx((n_exceed + 1) / (len(replicates) + 1))
    assert summary.seed.item() == 191
    fig = bootstrap.plot_null_distribution(replicates, summary)
    assert len(fig.axes) == 1
    assert fig.axes[0].get_xlabel() == "Likelihood-ratio statistic"
    plt.close(fig)
